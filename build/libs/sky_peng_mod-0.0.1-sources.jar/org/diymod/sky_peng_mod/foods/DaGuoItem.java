package org.diymod.sky_peng_mod.foods;

import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_6880;
import org.diymod.sky_peng_mod.Sky_peng_mod;
import org.diymod.sky_peng_mod.entity.PlayerSavedData;
import org.diymod.sky_peng_mod.effect.ModEffects;

public class DaGuoItem extends class_1792 {

    public DaGuoItem(class_1792.class_1793 settings) {
        super(settings);
    }

    // 食用完成事件
    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 world, class_1309 user) {

        class_1799 itemStack = super.method_7861(stack, world, user);
        if (user instanceof class_1657 player) {
            // Use dimension-independent saved data (falls back to in-memory if necessary)
            PlayerSavedData savedData = PlayerSavedData.get(world);
            int newCount = savedData.addDaGuoEaten(player.method_5667());

            if (player instanceof class_3222) {
                player.method_7353(class_2561.method_43470("已使用大果数量: " + newCount), false);
                String effect = "early";

                if (newCount == 5) {
                    player.method_7353(class_2561.method_43470("你因使用过多大果导致进入口腔癌初期！"), false);
                    // 给玩家口腔癌效果，持续 5 分钟（5*60*20 tick）
                    addPlayerEffect(player, ModEffects.EARLY_ORAL_CANCER, 60 * 5);
                    setOralCancerRemaining(player, "early", 60 * 5);
                } else if (newCount == 10) {
                    player.method_7353(class_2561.method_43470("你因使用过多大果导致进入口腔癌中期！"), false);

                    if (player.method_6059(class_6880.method_40223(ModEffects.EARLY_ORAL_CANCER))) {
                        player.method_6016(class_6880.method_40223(ModEffects.EARLY_ORAL_CANCER));
                    }

                    // 给玩家口腔癌中期效果，持续 5 分钟（5*60*20 tick）
                    addPlayerEffect(player, ModEffects.MIDDLE_ORAL_CANCER, 60 * 5);
                    setOralCancerRemaining(player, "middle", 60 * 5);
                } else if (newCount >= 15) {
                    player.method_7353(class_2561.method_43470("你因使用过多大果导致进入口腔癌晚期！"), false);

                    if (player.method_6059(class_6880.method_40223(ModEffects.MIDDLE_ORAL_CANCER))) {
                        player.method_6016(class_6880.method_40223(ModEffects.MIDDLE_ORAL_CANCER));
                    }

                    // 给玩家口腔癌晚期效果，持续 5 分钟（5*60*20 tick）
                    addPlayerEffect(player, ModEffects.LATE_ORAL_CANCER, 60 * 5);
                    setOralCancerRemaining(player, "late", 60 * 5);
                }
            }
        }
        return itemStack;
    }

    // 给角色增加效果
    public void addPlayerEffect(class_1657 player, class_1291 effect, int seconds) {
        player.method_6092(new class_1293(class_6880.method_40223(effect), 20 * seconds, 0));
    }

    // 设置口腔癌时间(存入PlayerSavedData，单位为秒)
    public void setOralCancerRemaining(class_1657 player, String effect, int seconds) {
        PlayerSavedData.get(player.method_73183()).setOralCancerRemaining(player.method_5667(), effect,20 * seconds);
    }
}
