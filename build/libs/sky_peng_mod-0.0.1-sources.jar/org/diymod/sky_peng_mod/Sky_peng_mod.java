package org.diymod.sky_peng_mod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.loader.impl.util.log.Log;
import net.fabricmc.loader.impl.util.log.LogCategory;
import net.minecraft.class_1293;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.diymod.sky_peng_mod.effect.ModEffects;
import org.diymod.sky_peng_mod.entity.EatTimeManager;
import org.diymod.sky_peng_mod.entity.ModItems;
import org.diymod.sky_peng_mod.entity.PlayerSavedData;

public class Sky_peng_mod implements ModInitializer {

    public static String MOD_ID = "sky_peng_mod";
    public static Logger LOGGER = LogManager.getLogger(MOD_ID);

    // 1. 创建物品组的注册键
    public static final class_5321<class_1761> CUSTOM_CREATIVE_TAB_KEY = class_5321.method_29179(
            class_7923.field_44687.method_46765(), class_2960.method_60655(MOD_ID, "creative_tab")
    );

    // 2. 创建物品组对象
    public static final class_1761 CUSTOM_CREATIVE_TAB = FabricItemGroup.builder()
            .method_47320(() -> new class_1799(ModItems.DIY_DAGUO))
            .method_47321(class_2561.method_43471("creativeTab.test-diy-food"))
            .method_47317((params, output) -> {
                output.method_45421(ModItems.DIY_DAGUO);
            })
            .method_47324();



    @Override
    public void onInitialize() {
        ModItems.initialize();
        ModEffects.initialize();
        initFoodUseDuration();

        class_2378.method_39197(class_7923.field_44687, CUSTOM_CREATIVE_TAB_KEY, CUSTOM_CREATIVE_TAB);

        // 加入游戏，恢复口腔癌时间
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
           class_3222 player =  handler.field_14140;
           class_2487 playerData = PlayerSavedData.get(player.method_51469()).getOralCancerRemaining(player.method_5667());
           player.method_7353(class_2561.method_43470("playerData:" + playerData), false);

           if (playerData == null) return;

           int oral_cancer_remaining = playerData.method_68083("oral_cancer_remaining", 0);
           String effect = playerData.method_10558("effect").orElse(null);

           if (oral_cancer_remaining > 0 && effect != null && !effect.isEmpty()) {
              player.method_7353(class_2561.method_43470("你还有 " + oral_cancer_remaining + " 秒的口腔癌效果未清除，快喝牛奶吧！"), false);

              switch (effect) {
                case "early":
                    player.method_7353(class_2561.method_43470("你进入了口腔癌初期！"), false);
                    player.method_6092(new class_1293(class_6880.method_40223(ModEffects.EARLY_ORAL_CANCER), oral_cancer_remaining * 20, 0));
                    PlayerSavedData.get(player.method_51469()).removeOralCancerRemaining(player.method_5667());
                    break;
                case "middle":
                    player.method_6092(new class_1293(class_6880.method_40223(ModEffects.MIDDLE_ORAL_CANCER), oral_cancer_remaining * 20, 0));
                    PlayerSavedData.get(player.method_51469()).removeOralCancerRemaining(player.method_5667());
                    player.method_7353(class_2561.method_43470("你进入了口腔癌中期！"), false);
                    break;
                case "late":
                    player.method_6092(new class_1293(class_6880.method_40223(ModEffects.LATE_ORAL_CANCER), oral_cancer_remaining * 20, 0));
                    PlayerSavedData.get(player.method_51469()).removeOralCancerRemaining(player.method_5667());
                    player.method_7353(class_2561.method_43470("你进入了口腔癌晚期！"), false);
                    break;
                default:
                    Log.warn(LogCategory.LOG, "未知的口腔癌效果类型: ", effect);
               }

           }
        });

        // 断开链接记录
        ServerPlayConnectionEvents.DISCONNECT.register((handler, sender) -> {
            class_3222 player =  handler.field_14140;
            class_1293 EARLY_ORAL_CANCER_Instance = player.method_6112(class_6880.method_40223(ModEffects.EARLY_ORAL_CANCER));
            class_1293 MIDDLE_ORAL_CANCER = player.method_6112(class_6880.method_40223(ModEffects.MIDDLE_ORAL_CANCER));
            class_1293 LATE_ORAL_CANCER = player.method_6112(class_6880.method_40223(ModEffects.LATE_ORAL_CANCER));
            if (EARLY_ORAL_CANCER_Instance != null) {
                PlayerSavedData.get(player.method_51469()).setOralCancerRemaining(player.method_5667(), "early",EARLY_ORAL_CANCER_Instance.method_5584() / 20);
            } else if (MIDDLE_ORAL_CANCER != null) {
                PlayerSavedData.get(player.method_51469()).setOralCancerRemaining(player.method_5667(), "middle", MIDDLE_ORAL_CANCER.method_5584() / 20);
            }else if (LATE_ORAL_CANCER != null) {
                PlayerSavedData.get(player.method_51469()).setOralCancerRemaining(player.method_5667(), "late", LATE_ORAL_CANCER.method_5584() / 20);
            } else {
                PlayerSavedData.get(player.method_51469()).removeOralCancerRemaining(player.method_5667());
            }
        });

        // 玩家破坏橡树树叶概率掉落大果
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (!world.method_8608() && state.method_27852(class_2246.field_10503)) {
                if (world.field_9229.method_43057() < 0.05f) { // 5%(0.05f) 的概率掉落大果
                    class_1799 daGuoStack = new class_1799(ModItems.DIY_DAGUO);
                    class_2248.method_9577(world, pos, daGuoStack);
                }
            }
        });
    }

    // 初始化自定义食物的食用时长
    public void initFoodUseDuration() {
        String daGuoItemId = class_7923.field_41178.method_10221(ModItems.DIY_DAGUO).toString();
        EatTimeManager.setItemModifier(daGuoItemId, 20f);
    }
}
