package org.diymod.sky_peng_mod.entity;

import com.mojang.serialization.Codec;
import java.util.UUID;
import net.minecraft.class_10741;
import net.minecraft.class_18;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_3218;

/**
 * Dimension-independent SavedData for storing per-player mod data.
 * - In server worlds: stored in the Overworld's data storage (so it's shared across dimensions)
 * - Fallback (no server available): in-memory singleton (useful in some client-only or test contexts)
 */
public class PlayerSavedData extends class_18 {
    private static final String DATA_NAME = "diymod_playerdata";

    private class_2487 players = new class_2487();

    private static final Codec<PlayerSavedData> CODEC = class_2487.field_25128.xmap(
            PlayerSavedData::new,
            PlayerSavedData::getPlayerData
    );

    private static final class_10741<PlayerSavedData> TYPE = new class_10741<>(
            DATA_NAME, // The unique name for this saved data.
            PlayerSavedData::new,
            CODEC,
            null
    );

    public PlayerSavedData() {}

    public PlayerSavedData(class_2487 players) {
        this.players = players;
    }

    public static PlayerSavedData get(class_1937 level) {
        if (level instanceof class_3218) {
            class_3218 serverLevel = level.method_8503().method_3847(class_3218.field_25179);
            if (serverLevel != null) {
                return serverLevel.method_17983().method_17924(TYPE);
            }
        }
        // fallback in-memory
        return new PlayerSavedData();
    }

    public class_2487 getPlayerData() {
        return players;
    }

    public class_2487 getPlayerDataByUUID(UUID uuid) {
        String key = uuid.toString();
        return players.method_10545(key) ? players.method_10562(key).orElse(null) : new class_2487();
    }

    public void putPlayerData(UUID uuid, class_2487 tag) {
        players.method_10566(uuid.toString(), tag);
        method_80();
    }

    public void setDaGuoEaten(UUID uuid, int count) {
        class_2487 t = getPlayerDataByUUID(uuid);
        t.method_10569("da_guo_eaten", count);
        putPlayerData(uuid, t);
    }

    public int addDaGuoEaten(UUID uuid) {
        class_2487 t = getPlayerDataByUUID(uuid);
        int val = t.method_10545("da_guo_eaten") ? t.method_68083("da_guo_eaten", 0) : 0;
        val++;
        t.method_10569("da_guo_eaten", val);
        putPlayerData(uuid, t);
        return val;
    }

    public void setOralCancerRemaining(UUID uuid, String effect, int ticks) {
        class_2487 t = getPlayerDataByUUID(uuid);
        if (ticks > 0) {
            t.method_10582("effect", effect);
            t.method_10569("oral_cancer_remaining", ticks);
        } else {
            t.method_10582("effect", effect);
            t.method_10551("oral_cancer_remaining");
        }
        putPlayerData(uuid, t);
    }

    public class_2487 getOralCancerRemaining(UUID uuid) {
        class_2487 t = getPlayerDataByUUID(uuid);
        return t.method_10545("oral_cancer_remaining") ? t : null;
    }

    public void removeOralCancerRemaining(UUID uuid) {
        class_2487 t = getPlayerDataByUUID(uuid);
        t.method_10551("oral_cancer_remaining");
        t.method_10551("effect");
        putPlayerData(uuid, t);
    }

}
