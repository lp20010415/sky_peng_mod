package org.diymod.sky_peng_mod.entity;

import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.world.item.*;
import org.diymod.sky_peng_mod.component.DaGuoFoodComponent;
import org.diymod.sky_peng_mod.consumeComponent.DaGuoConsumeComponent;
import org.diymod.sky_peng_mod.foods.DaGuoItem;

import java.util.function.Function;

import static org.diymod.sky_peng_mod.Sky_peng_mod.MOD_ID;

public class ModItems {

    public static final class_1792 DIY_DAGUO = register("da_guo", DaGuoItem::new,
            new class_1792.class_1793().method_62833(
                    DaGuoFoodComponent.DAGUO_COMPONENT,
                    DaGuoConsumeComponent.DaGuo_CONSUMABLE_COMPONENT
            ));

    public static <T extends class_1792> T register(String name, Function<class_1792.class_1793, T> itemFactory, class_1792.class_1793 settings) {
        // Create the item key.
        class_5321<class_1792> itemKey = class_5321.method_29179(class_7924.field_41197, class_2960.method_60655(MOD_ID, name));

        // Create the item instance.
        T item = itemFactory.apply(settings.method_63686(itemKey));

        // Register the item.
        class_2378.method_39197(class_7923.field_41178, itemKey, item);

        return item;
    }

    public static void initialize() {
    }

}
