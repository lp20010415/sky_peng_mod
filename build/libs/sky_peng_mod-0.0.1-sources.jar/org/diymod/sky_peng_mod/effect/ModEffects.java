package org.diymod.sky_peng_mod.effect;

import static org.diymod.sky_peng_mod.Sky_peng_mod.MOD_ID;

import net.minecraft.class_1291;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModEffects {

    public static final class_1291 EARLY_ORAL_CANCER = register("early_oral_cancer", new EarlyOralCancerMobEffect());
    public static final class_1291 MIDDLE_ORAL_CANCER = register("middle_oral_cancer", new MiddleOralCancerMobEffect());
    public static final class_1291 LATE_ORAL_CANCER = register("late_oral_cancer", new LateOralCancerMobEffect());

    private static <T extends class_1291> T register(String name, T effect) {
        return class_2378.method_10230(class_7923.field_41174, class_2960.method_60655(MOD_ID, name), effect);
    }

    public static void initialize() {
        // 留空以便在 mod 初始化时引用类触发注册（如果需要）
    }
}
