package org.diymod.sky_peng_mod.effect;

import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import net.minecraft.class_4081;
import org.diymod.sky_peng_mod.Sky_peng_mod;
import org.diymod.sky_peng_mod.entity.PlayerSavedData;
import org.diymod.sky_peng_mod.entity.EatTimeManager;

public class EarlyOralCancerMobEffect extends class_1291 {
    // 口腔癌早期
    // 初期颜色代码 FF6347
    // 中期颜色代码 DC143C
    // 晚期颜色代码 8B0000

    public EarlyOralCancerMobEffect() {
        super(class_4081.field_18272, 0xFF6347);
    }

    @Override
    public void onEffectStarted(class_1293 effectInstance, class_1309 entity) {
        if (entity instanceof class_1657 player) {
            EatTimeManager.setPlayerMultiplier(player.method_5667(), 2f); // 将吃东西时长改为原来的一倍
        }
        super.onEffectStarted(effectInstance, entity);
    }

    @Override
    public void onEffectRemoved(class_1293 effectInstance, class_1309 entity) {
        if (entity instanceof class_1657 player) {
            class_2487 playerData = PlayerSavedData.get(player.method_73183()).getPlayerDataByUUID(player.method_5667());
            if (playerData != null) {
                int oral_cancer_remaining = playerData.method_68083("oral_cancer_remaining", 0);

                Sky_peng_mod.LOGGER.info("early_oral_cancer_remaining：" + oral_cancer_remaining);

                if (oral_cancer_remaining <= 0) {

                    PlayerSavedData savedData = PlayerSavedData.get(player.method_73183());
                    // 清除大果计数
                    savedData.setDaGuoEaten(player.method_5667(), 0);
                    // 恢复吃东西速度
                    EatTimeManager.setPlayerMultiplier(player.method_5667(), 1.0f);
                }
            }
        }

        super.onEffectRemoved(effectInstance, entity);
    }
}
