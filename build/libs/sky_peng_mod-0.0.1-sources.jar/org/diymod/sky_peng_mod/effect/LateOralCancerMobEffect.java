package org.diymod.sky_peng_mod.effect;



import org.diymod.sky_peng_mod.entity.PlayerSavedData;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_4081;
import org.diymod.sky_peng_mod.entity.EatTimeManager;

public class LateOralCancerMobEffect extends class_1291 {
    // 口腔癌晚期
    // 初期颜色代码 FF6347
    // 中期颜色代码 DC143C
    // 晚期颜色代码 8B0000

    public LateOralCancerMobEffect() {
        super(class_4081.field_18272, 0x8B0000);
    }

    // 触发检查，返回参数则为每 tick 是否触发 applyEffectTick 方法
    @Override
    public boolean method_5552(int i, int j) {
        // 每20 tick(1秒)触发一次
        return i % 20 == 0;
    }

    @Override
    public void method_52520(class_1309 livingEntity, int i) {
        if (livingEntity instanceof class_1657 player) {
            EatTimeManager.setPlayerMultiplier(player.method_5667(), 10f); // 将吃东西时长改为原来的10倍
        }
        super.method_52520(livingEntity, i);
    }

    // 每 tick 检查效果
    @Override
    public boolean method_5572(class_3218 serverLevel, class_1309 livingEntity, int i) {
        if (livingEntity instanceof class_1657 player) {
            float newHealth = Math.max(2, player.method_6032() - 2f);
            player.method_6033(newHealth);
        }
        return super.method_5572(serverLevel, livingEntity, i);
    }

    // 效果结束
    @Override
    public void onEffectRemoved(class_1293 effectInstance, class_1309 entity) {
        super.onEffectRemoved(effectInstance, entity);
        if (entity instanceof class_1657 player && !player.method_29504()) {
            PlayerSavedData savedData = PlayerSavedData.get(player.method_73183());

            if (effectInstance.method_5584() <= 0) {
                // 只有自然到期(duration <= 0)，才会杀死玩家
                player.method_6033(0);
                // 清除大果计数
                savedData.setDaGuoEaten(player.method_5667(), 0);
                // 恢复吃东西速度
                EatTimeManager.setPlayerMultiplier(player.method_5667(), 1.0f);
                // 删除计时
                savedData.removeOralCancerRemaining(player.method_5667());
            } else {
                boolean isAmbient = effectInstance.method_5591();
                boolean isVisible = effectInstance.method_5581();
                player.method_7353(class_2561.method_43470(
                         "参数2：" + isVisible + "参数3：" + isAmbient), false);
//                player.addEffect(new MobEffectInstance(Holder.direct(ModEffects.LATE_ORAL_CANCER), effectInstance.getDuration(), 0));
            }

        }
    }


}
