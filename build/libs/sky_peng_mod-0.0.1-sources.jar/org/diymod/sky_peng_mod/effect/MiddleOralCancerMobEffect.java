package org.diymod.sky_peng_mod.effect;

import org.diymod.sky_peng_mod.entity.PlayerSavedData;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_4081;
import org.diymod.sky_peng_mod.entity.EatTimeManager;

public class MiddleOralCancerMobEffect extends class_1291 {
    // 口腔癌晚期
    // 初期颜色代码 FF6347
    // 中期颜色代码 DC143C
    // 晚期颜色代码 8B0000

    public MiddleOralCancerMobEffect() {
        super(class_4081.field_18272, 0xDC143C);
    }

    // 触发检查，返回参数则为每 tick 是否触发 applyEffectTick 方法
    @Override
    public boolean method_5552(int i, int j) {
        // 每20 tick(1秒)触发一次
        return i % 20 == 0;
    }

    @Override
    public void method_52520(class_1309 livingEntity, int i) {
        if (livingEntity instanceof class_1657 player) {
            EatTimeManager.setPlayerMultiplier(player.method_5667(), 5f); // 将吃东西时长改为原来的5倍
        }
        super.method_52520(livingEntity, i);
    }

    // 每 tick 检查效果
    @Override
    public boolean method_5572(class_3218 serverLevel, class_1309 livingEntity, int i) {
        if (livingEntity instanceof class_1657 player) {
            float newHealth = Math.max(1, player.method_6032() - 1f);
            player.method_6033(newHealth);
        }
        return super.method_5572(serverLevel, livingEntity, i);
    }

    @Override
    public void onEffectRemoved(class_1293 effectInstance, class_1309 entity) {
        if (entity instanceof class_1657 player) {
            class_2487 playerData = PlayerSavedData.get(player.method_73183()).getPlayerDataByUUID(player.method_5667());
            if (playerData != null) {
                int oral_cancer_remaining = playerData.method_68083("oral_cancer_remaining", 0);
                if (oral_cancer_remaining <= 0) {

                    PlayerSavedData savedData = PlayerSavedData.get(player.method_73183());
                    // 清除大果计数
                    savedData.setDaGuoEaten(player.method_5667(), 0);
                    // 恢复吃东西速度
                    EatTimeManager.clearAll();
                }
            }
        }
        super.onEffectRemoved(effectInstance, entity);
    }
}
