package org.diymod.sky_peng_mod.mixin;

import org.diymod.sky_peng_mod.effect.ModEffects;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Collection;
import java.util.Objects;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1309;
import net.minecraft.class_6880;

@Mixin(class_1309.class)
public class LivingEntityMixin {

    @Inject(method = "removeAllEffects", at = @At("HEAD"), cancellable = true)
    private void onClearStatusEffects(CallbackInfoReturnable<Boolean> cir) {
        class_1309 livingEntity = (class_1309)(Object)this;
        class_6880<class_1291> lateOralCancer = class_6880.method_40223(ModEffects.LATE_ORAL_CANCER);

        // 如果有口腔癌晚期效果，阻止默认的清除行为并仅移除其他效果。
        if (livingEntity.method_6059(lateOralCancer)) {
            java.util.List<class_6880<class_1291>> toRemove = new java.util.ArrayList<>();
            for (class_1293 inst : livingEntity.method_6026()) {
                if (!Objects.equals(inst.method_5579(), lateOralCancer)) {
                    toRemove.add(inst.method_5579());
                }
            }

            for (class_6880<class_1291> eff : toRemove) {
                livingEntity.method_6016(eff);
            }
            // 取消原方法执行，防止晚期效果被原版继续移除。
            cir.setReturnValue(false);
        }
    }

}
