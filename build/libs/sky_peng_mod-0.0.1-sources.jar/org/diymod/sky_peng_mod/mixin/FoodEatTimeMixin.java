package org.diymod.sky_peng_mod.mixin;

import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import org.diymod.sky_peng_mod.entity.EatTimeManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1792.class)
public class FoodEatTimeMixin {

    @Inject(method = "getUseDuration", at = @At("RETURN"), cancellable = true)
    private void modifyFoodUseDuration(class_1799 itemStack, class_1309 livingEntity, CallbackInfoReturnable<Integer> cir) {
        // 调用动态时长计算逻辑

        int newDuration = EatTimeManager.getModifiedEatTime(itemStack, livingEntity, cir.getReturnValue());
        if (newDuration != cir.getReturnValue()) {
            cir.setReturnValue(newDuration);
        }
    }

}
