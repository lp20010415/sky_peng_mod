package org.diymod.sky_peng_mod.component;

import net.minecraft.class_4174;

public class DaGuoFoodComponent {

    public static final class_4174 DAGUO_COMPONENT = new class_4174.class_4175()
            .method_19238(1)                   // 恢复的饥饿值，每1点=半个鸡腿，4=2个鸡腿
            .method_19237(0.3f)     // 饱和度，影响饥饿消耗的速度
            .method_19240()                 // 可选：是否可以在饱的时候继续吃
            .method_19242();

}
