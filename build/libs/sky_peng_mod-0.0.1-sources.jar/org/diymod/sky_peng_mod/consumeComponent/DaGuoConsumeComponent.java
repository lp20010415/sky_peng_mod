package org.diymod.sky_peng_mod.consumeComponent;

import net.minecraft.class_10124;
import net.minecraft.class_10128;
import net.minecraft.class_10132;
import net.minecraft.class_1293;
import net.minecraft.class_1294;

public class DaGuoConsumeComponent {

    /**
     * 食用大果后赋予的效果
     * 夜视、急迫2、迅捷2
     */
    public static final class_10124 DaGuo_CONSUMABLE_COMPONENT = class_10128.method_62858()
            // The duration is in ticks, 20 ticks = 1 second
            .method_62854(new class_10132(new class_1293(class_1294.field_5925, 120 * 20, 0), 1.0f))
            .method_62854(new class_10132(new  class_1293(class_1294.field_5917, 120 * 20, 1), 1.0f))
            .method_62854(new class_10132(new  class_1293(class_1294.field_5904, 120 * 20, 1), 1.0f))
            .method_62851();

}
