package org.diymod.test_diy_food.entity;

import com.mojang.serialization.MapCodec;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.consume_effects.ConsumeEffect;
import net.minecraft.world.level.Level;

public class FoodConsumableComponent {

    // 自定义消费效果：跟踪吃“大果”数量



}
