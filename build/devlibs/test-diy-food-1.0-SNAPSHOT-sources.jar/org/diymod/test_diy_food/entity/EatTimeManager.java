package org.diymod.test_diy_food.entity;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.BiFunction;

public class EatTimeManager {

    // 全局时长修改函数（可以随时替换）
    private static BiFunction<ItemStack, LivingEntity, Float> durationModifier = (stack, entity) -> 2.0f;

    // 玩家独立的时长修改函数（键为玩家UUID）
    private static final Map<UUID, BiFunction<ItemStack, LivingEntity, Float>> playerModifiers = new HashMap<>();

    // 特定物品的时长修改函数
    private static final Map<String, BiFunction<ItemStack, LivingEntity, Float>> itemModifiers = new HashMap<>();

    // 默认倍数
    private static float defaultMultiplier = 1.0f;
    private static boolean enabled = true;

    /**
     * 获取修改后的食用时长
     * @param stack 食物物品栈
     * @param user 使用者
     * @param originalDuration 原始时长（ticks）
     * @return 修改后的时长（ticks）
     */
    public static int getModifiedEatTime(ItemStack stack, LivingEntity user, int originalDuration) {
        if (!enabled) return originalDuration;

        float multiplier = defaultMultiplier;

        // 1. 检查玩家特定修改器
        if (user instanceof Player player) {
            UUID uuid = player.getUUID();
            if (playerModifiers.containsKey(uuid)) {
                float playerMulti = playerModifiers.get(uuid).apply(stack, user);
                if (playerMulti > 0) multiplier = playerMulti;
            }
        }

        // 2. 检查物品特定修改器（优先级最高）
        String itemId = stack.getItem().toString();
        if (itemModifiers.containsKey(itemId)) {
            float itemMulti = itemModifiers.get(itemId).apply(stack, user);
            if (itemMulti > 0) multiplier = itemMulti;
        }

        // 3. 检查全局修改器
        if (durationModifier != null) {
            float globalMulti = durationModifier.apply(stack, user);
            if (globalMulti > 0) multiplier = globalMulti;
        }

        // 计算新时长（确保是整数且不小于最小值）
        int newDuration = (int)(originalDuration * multiplier);
        newDuration = Math.max(10, newDuration);  // 最短0.5秒
        newDuration = Math.min(400, newDuration); // 最长20秒

        return newDuration;
    }

    // ========== 动态调整方法 ==========

    /**
     * 设置全局倍数
     */
    public static void setGlobalMultiplier(float multiplier) {
        defaultMultiplier = Math.max(0.5f, Math.min(10f, multiplier));
    }

    /**
     * 设置全局自定义函数
     */
    public static void setGlobalModifier(BiFunction<ItemStack, LivingEntity, Float> modifier) {
        durationModifier = modifier;
    }

    /**
     * 设置特定玩家的倍数
     */
    public static void setPlayerMultiplier(UUID playerUuid, float multiplier) {
        playerModifiers.put(playerUuid, (stack, entity) -> multiplier);
    }

    /**
     * 设置特定玩家的自定义函数
     */
    public static void setPlayerModifier(UUID playerUuid, BiFunction<ItemStack, LivingEntity, Float> modifier) {
        playerModifiers.put(playerUuid, modifier);
    }


    /**
     * 移除玩家修改器
     */
    public static void removePlayerModifier(UUID playerUuid) {
        playerModifiers.remove(playerUuid);
    }


    /**
     * 清除所有自定义设置
     */
    public static void clearAll() {
        playerModifiers.clear();
        itemModifiers.clear();
        durationModifier = null;
        defaultMultiplier = 2.0f;
        enabled = true;
    }
}
