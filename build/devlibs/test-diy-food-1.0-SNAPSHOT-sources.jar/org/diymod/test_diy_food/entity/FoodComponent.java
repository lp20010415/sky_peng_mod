package org.diymod.test_diy_food.entity;

import net.minecraft.world.food.FoodProperties;

public class FoodComponent {

    public static final FoodProperties DAGUO_COMPONENT = new FoodProperties.Builder()
            .nutrition(1)                   // 恢复的饥饿值，每1点=半个鸡腿，4=2个鸡腿
            .saturationModifier(0.6f)     // 饱和度，影响饥饿消耗的速度
            .alwaysEdible()                 // 可选：是否可以在饱的时候继续吃
            .build();

}
