package org.diymod.test_diy_food.effect;

import net.minecraft.core.Holder;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.diymod.test_diy_food.PlayerSavedData;
import org.diymod.test_diy_food.entity.EatTimeManager;

public class EarlyOralCancerMobEffect extends MobEffect {
    // 口腔癌早期
    // 初期颜色代码 FF6347
    // 中期颜色代码 DC143C
    // 晚期颜色代码 8B0000

    public EarlyOralCancerMobEffect() {
        super(MobEffectCategory.HARMFUL, 0xFF6347);
    }

    @Override
    public void onEffectStarted(MobEffectInstance effectInstance, LivingEntity entity) {
        if (entity instanceof Player player) {
            EatTimeManager.setPlayerMultiplier(player.getUUID(), 0.5f); // 将吃东西速度降低为原来的一半
        }
        super.onEffectStarted(effectInstance, entity);
    }

    @Override
    public void onEffectRemoved(MobEffectInstance effectInstance, LivingEntity entity) {
        if (entity instanceof Player player) {
            CompoundTag playerData = PlayerSavedData.get(player.level()).getPlayerDataByUUID(player.getUUID());
            if (playerData != null) {
                int oral_cancer_remaining = playerData.getIntOr("oral_cancer_remaining", 0);
                if (oral_cancer_remaining <= 0) {

                    PlayerSavedData savedData = PlayerSavedData.get(player.level());
                    // 清除大果计数
                    savedData.setDaGuoEaten(player.getUUID(), 0);
                    // 恢复吃东西速度
                    EatTimeManager.setPlayerMultiplier(player.getUUID(), 1.0f);
                }
            }
        }

        super.onEffectRemoved(effectInstance, entity);
    }
}
